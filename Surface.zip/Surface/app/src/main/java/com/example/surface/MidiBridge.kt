package com.example.surface

import android.app.Activity
import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiInputPort
import android.media.midi.MidiManager
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

/**
 * Implements the `window.AndroidMidi` object the HTML expects:
 * listPorts(), connect(id), disconnect(), sendCC(ch, cc, value),
 * saveLayout(json), loadLayout().
 * Calls back into JS via __midiConnected / __midiDisconnected / __midiError / __midiDevicesChanged.
 */
class MidiBridge(activity: Activity, private val webView: WebView) {

    private val main = Handler(Looper.getMainLooper())
    private val midi = activity.getSystemService(Context.MIDI_SERVICE) as MidiManager
    private val prefs = activity.getSharedPreferences("surface", Context.MODE_PRIVATE)

    private var device: MidiDevice? = null
    private var port: MidiInputPort? = null
    private var connectedId = -1

    private val deviceCallback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(info: MidiDeviceInfo) {
            js("if (window.__midiDevicesChanged) __midiDevicesChanged();")
        }

        override fun onDeviceRemoved(info: MidiDeviceInfo) {
            if (connectedId == info.id) {
                closeDevice()
                js("if (window.__midiDisconnected) __midiDisconnected();")
            }
            js("if (window.__midiDevicesChanged) __midiDevicesChanged();")
        }
    }

    init {
        midi.registerDeviceCallback(deviceCallback, main)
    }

    @JavascriptInterface
    fun listPorts(): String {
        val arr = JSONArray()
        for (info in midi.devices) {
            // Only devices that accept MIDI input can be controlled from here.
            if (info.inputPortCount == 0) continue
            arr.put(
                JSONObject()
                    .put("id", info.id)
                    .put("name", nameOf(info))
                    .put("inputs", info.inputPortCount)
                    .put("outputs", info.outputPortCount)
            )
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun connect(id: Int) {
        closeDevice()
        val info = midi.devices.firstOrNull { it.id == id }
        if (info == null) {
            js("if (window.__midiError) __midiError('device not found');")
            return
        }
        val name = nameOf(info)
        midi.openDevice(info, MidiManager.OnDeviceOpenedListener { dev ->
            if (dev == null) {
                js("if (window.__midiError) __midiError('could not open device');")
                return@OnDeviceOpenedListener
            }
            val inPort = dev.openInputPort(0)
            if (inPort == null) {
                dev.close()
                js("if (window.__midiError) __midiError('no MIDI input port');")
                return@OnDeviceOpenedListener
            }
            device = dev
            port = inPort
            connectedId = id
            js("if (window.__midiConnected) __midiConnected(${JSONObject.quote(name)});")
        }, main)
    }

    @JavascriptInterface
    fun disconnect() {
        closeDevice()
        js("if (window.__midiDisconnected) __midiDisconnected();")
    }

    @JavascriptInterface
    fun sendCC(ch: Int, cc: Int, value: Int) {
        val status = 0xB0 or ((ch - 1) and 0x0F)
        val bytes = byteArrayOf(
            status.toByte(),
            (cc and 0x7F).toByte(),
            (value and 0x7F).toByte()
        )
        port?.send(bytes, 0, bytes.size)
    }

    @JavascriptInterface
    fun saveLayout(json: String) {
        prefs.edit().putString("layout", json).apply()
    }

    @JavascriptInterface
    fun loadLayout(): String = prefs.getString("layout", "") ?: ""

    fun close() {
        closeDevice()
        midi.unregisterDeviceCallback(deviceCallback)
    }

    private fun closeDevice() {
        try { port?.close() } catch (_: Exception) {}
        try { device?.close() } catch (_: Exception) {}
        port = null
        device = null
        connectedId = -1
    }

    private fun nameOf(info: MidiDeviceInfo): String =
        info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI device"

    private fun js(code: String) {
        main.post { webView.evaluateJavascript(code, null) }
    }
}
